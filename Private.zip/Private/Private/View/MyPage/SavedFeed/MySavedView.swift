//
//  MySavedView.swift
//  Private
//
//  Created by 주진형 on 2023/09/25.
//

import SwiftUI
import Kingfisher

struct MySavedView: View {
    
    @EnvironmentObject private var userStore: UserStore
    
    var columns: [GridItem] = [GridItem(.fixed(.screenWidth*0.95*0.3), spacing: 1, alignment:  nil),
                               GridItem(.fixed(.screenWidth*0.95*0.3), spacing: 1, alignment:  nil),
                               GridItem(.fixed(.screenWidth*0.95*0.3), spacing: 1, alignment:  nil)]
    var body: some View {
        ScrollView {
            if userStore.mySavedFeedList.isEmpty {
                Text("저장한 피드가 없습니다")
                    .font(.pretendardBold24)
                    .padding(.top, .screenHeight * 0.2 + 37.2)
            } else {
                LazyVGrid(
                    columns: columns,
                    alignment: .center,
                    spacing: 1
                ) {
                    ForEach(userStore.mySavedFeedList, id: \.self) { feed in
                        KFImage(URL(string:feed.images[0])) .placeholder {
                            Image(systemName: "photo")
                        }.resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: .screenWidth*0.95*0.3 ,height: .screenWidth*0.95*0.3)
                            .clipShape(Rectangle())
                    }
                }
            }
        }
    }
}

struct MySavedView_Previews: PreviewProvider {
    static var previews: some View {
        MySavedView().environmentObject(UserStore())
    }
}
