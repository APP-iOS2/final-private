//
//  MapToChatRoomView.swift
//  Private
//
//  Created by yeon I on 2023/09/26.
//

import SwiftUI

struct MapToChatRoomView: View {
    var body: some View {
        Text("Hello, World!")
    }
}

struct MapToChatRoomView_Previews: PreviewProvider {
    static var previews: some View {
        MapToChatRoomView()
    }
}
