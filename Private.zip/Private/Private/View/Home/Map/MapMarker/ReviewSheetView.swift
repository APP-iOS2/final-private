//
//  ReviewSheetView.swift
//  Private
//
//  Created by yeon I on 2023/09/25.
//

import SwiftUI
import NMapsMap

struct ReviewSheetView: View {
    var feeds: [Feed]
    
    var body: some View {
        NavigationView {
            HStack{
                //6줄 (사진크기에 맞게 6줄 이상은 잘라줘.)
                List(feeds, id: \.id) { feed in
                    VStack(alignment: .leading, spacing: 10) {
                        ForEach(feed.images, id: \.self) { imageName in
                            HStack {
                                VStack(alignment: .leading, spacing: 10) {
                                    Image(feed.writerProfileImage)
                                        .resizable()
                                        .aspectRatio(contentMode: .fit)
                                        .frame(height: 70)
                                        .clipShape(Circle())
                                }
                                VStack {
                                    Text(feed.writerNickname).font(.pretendardBold18)
                                    Text(feed.writerName).font(.pretendardRegular14)
                                }
                            }
                            HStack{
                                VStack{
                                    Image(imageName)
                                        .resizable()
                                        .aspectRatio(contentMode: .fit)
                                        .frame(width:130, height: 130 )
                                  
                                } .cornerRadius(10)
                                VStack(alignment: .leading ) {
                                    Text(feed.contents).font(.pretendardRegular14)
                                        .padding(.top, 10)
                                        .lineSpacing(3)
                                    Spacer()
                                }
                            }
                        } //이미지
                    }
                }
            }
        }
        .navigationBarTitle("팔로워의 리뷰", displayMode: .inline)
    }
}
struct ReviewSheetView_Previews: PreviewProvider {
    static var previews: some View {
        ReviewSheetView(
            feeds: []
        )
    }
}
